# Repository: ADSO 3063934
## Analysis & Software Development
### SENA - Caldas Regional
---
## URL Resources
- [Drive Documentation](https://drive.google.com/drive/folders/1cUEOsM44rpspMfyWvY_YlnXlIm9uffej?usp=share_link)
- [Repositories List](https://docs.google.com/spreadsheets/d/1M3B-qwrJN2wbeZmIBoA3r0hnP8yy4CKf2euV1oF61os/edit?usp=sharing)
- [Netlify Site](https://feliperestrepo3063934.netlify.app/)

---
## URL Utils
- [SVG Backgrounds](https://www.svgbackgrounds.com/set/free-svg-backgrounds-and-patterns/)
- [Image color picker](https://imagecolorpicker.com/#google_vignette)
- [Font Awesome](https://fontawesome.com/icons)
