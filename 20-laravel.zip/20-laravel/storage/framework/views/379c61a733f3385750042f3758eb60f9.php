<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<?php
if (Auth::user()->role == 'administrator') {
    $image = 'images/admin.png';
} else {
    $image = 'images/customer.png';
}
?>

<body class="min-h-[100dvh] bg-[url(<?php echo e(asset($image)); ?>)] bg-center bg-cover bg-fixed flex flex-col gap-4 items-center justify-center w-full flex p-6 pt-20 ">
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('js'); ?>

</body>
</html><?php /**PATH C:\Users\restr\OneDrive\Desktop\Dias\Martes\adso3063934\20-laravel\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>