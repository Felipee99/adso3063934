<?php $__env->startSection('title', 'login: Larapets 🐶'); ?>

<?php $__env->startSection('content'); ?>
    <section class=" bg-[#0006] rounded-lg w-4/16 p-6 flex flex-col gap-4 items-center justify-center">
        <h1 class="flex gap-4 justify-center items-center text-4-x1">
            <svg xmlns="http://www.w3.org/2000/svg" size-12 fill="currentColor" viewBox="0 0 256 256"><path d="M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"></path></svg>
            Login
        </h1>
            <div class="card w-full max-w-sm">
            <form method="POST" action="<?php echo e(route('login')); ?>" class="card-body">
                <?php echo csrf_field(); ?>
                <label class="label">Email:</label>
                <input type="text" class="input bg-[#0006]" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="badge badge-error w-full mt-1 py-6"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="label">Password</label>
                <input type="password" class="input bg-[#0006]" name=password placeholder="Password" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="badge badge-error w-full mt-1 py-6"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button class="btn btn-outline hover:bg-[#fff6] hover:text-white mt-4">Login</button>

                <p class="text-sm text-center mt-4">
                    Don’t have an account?
                    <a href="<?php echo e(route('register')); ?>" class="link link-default">
                        Sign up
                    </a>
                </p>

                 <p class="text-sm text-center mt-2">
                    <a  class="link link-default" href="<?php echo e(route('password.request')); ?>">
                        forgot your password?
                    </a>
                </p>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\restr\OneDrive\Desktop\Dias\Martes\adso3063934\20-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>