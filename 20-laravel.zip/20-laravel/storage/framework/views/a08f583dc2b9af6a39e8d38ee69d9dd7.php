<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\restr\OneDrive\Desktop\Dias\Martes\adso3063934\20-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>