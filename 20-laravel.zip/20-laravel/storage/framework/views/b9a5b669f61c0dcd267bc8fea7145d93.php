<?php $__env->startSection('title', 'dashboard ADMIN: Larapets'); ?>

<?php $__env->startSection('content'); ?>

    <h1>Dashboard</h1>
    <h2><?php echo e(Auth::user()->fullname); ?></h2>
    <h3>You're logged in!</h3>
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <a href="route('logout')" onclick="event.preventDefault();
                                            this.closest('form').submit();">
            Log out
        </a>
    </form>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\restr\OneDrive\Desktop\Dias\Martes\adso3063934\20-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>