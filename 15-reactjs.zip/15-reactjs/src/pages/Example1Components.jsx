import BtnBack from "../components/BtnBack";
import "../components/BtnBack.css";

// components Charmander
function Charmander() {
  return (
    <div
      style={{
        border: "4px solid orange",
        padding: "1.4rem",
        borderRadius: "0.4rem",
        background: "#fff0e6",
        width: "360px",
        color: "#333",
      }}
    >
      <h2>🔥 Charmander</h2>
      <p>Type: fire</p>
      <p>Ability: Blaze</p>
    </div>
  );
}

function Pikachu() {
  return (
    <div
      style={{
        border: "4px solid yellow",
        padding: "1.4rem",
        borderRadius: "0.4rem",
        background: "#fff0e6",
        width: "360px",
        color: "#333",
      }}
    >
      <h2>⚡ Pikachu</h2>
      <p>Type: electric</p>
      <p>Ability: Static</p>
    </div>
  );
}
function Squirtle() {
  return (
    <div
      style={{
        border: "4px solid blue",
        padding: "1.4rem",
        borderRadius: "0.4rem",
        background: "#fff0e6",
        width: "360px",
        color: "#333",
      }}
    >
      <h2>💧 Squirtle</h2>
      <p>Type: water</p>
      <p>Ability: Torrent</p>
    </div>
  );
}

function Example1Components() {
  return (
    <div className="container">
      <BtnBack />
      <h2>Example 1: Components</h2>
      <p>Create independent reusable UI pieces.</p>
      <div style={{ display: "flex", gap: "1rem" }}>
        <Charmander />
        <Pikachu />
        <Squirtle />
      </div>
    </div>
  );
}

export default Example1Components;
