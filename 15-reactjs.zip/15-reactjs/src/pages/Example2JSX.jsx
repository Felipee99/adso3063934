import BtnBack from "../components/BtnBack";

function Example2JSX() {
  // JS variable

  const pkName = "Bulbasaur";
  const pkType = "grass/poison";
  const pkLevel = 5;
  const pkAbilities = ["Overgrow", "Chlorophyll"];
  const pkImgUrl =
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png";

  // Style object
  const styles = {
    container: {
      background: "#e8f5e8",
      color: "#143656",
      padding: "1.2rem",
      marginTop: "1rem",
      borderRadius: "10px",
    },

    title: {
      color: "#143656",
      fontSize: "2rem",
      textAlign: "center",
    },
    img: {
      display: "flex",
      margin: "1rem auto",
      width: "150px",
    },
    ul: {
      paddingLeft: "2rem",
      fontSize: "0.8rem",
    },
  };

  return (
    <div className="container">
      <BtnBack />
      <h2>Example 2: JSX</h2>
      <p>
        Writing HTML-like code whitin JavaScript using curly braces {} for JS
        expresions
      </p>
      <div style={styles.container}>
        <h3 style={styles.title}>
          {pkName}(Lvl.{pkLevel})
        </h3>
        <img src={pkImgUrl} alt={pkName} style={styles.img} />
        <p>type: {pkType}</p>
        <p>Uppercase: {pkName.toUpperCase()}</p>
        <p>abilities:</p>
        <ul style={styles.ul}>
          {pkAbilities.map((ability, index) => (
            <li key={index}>{ability}</li>
          ))}
        </ul>
        <p>Is it a starter? {pkLevel === 5 ? '✅Yes' : '✖️No'}</p>
      </div>
    </div>
  );
}

export default Example2JSX;
